# SPARKS-FOUNDATION

I have completed #task1 as a Web Development and Designing Intern at The Sparks Foundation for batch #GRIPNOVEMBER22 #GRIPNOV22.
#html #internship 
Here are the details :
#task1: Basic Banking System
The task was to create a simple web application to make transactions between users, see all the users, send money to any user, select and view a particular user, and view the transaction history of the customers.

Technologies Used:
Frontend: Html, CSS  and JavaScript
Backend: PHP and MySQL
IDE: Visual Studio Code

